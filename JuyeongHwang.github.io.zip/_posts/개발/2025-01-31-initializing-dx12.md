---
layout: post
title:  Initializing DirectX 12
excerpt: "'Introduction to Direct3D 12'를 번역 및 정리한 포스트."
date:   2025-01-31
image:  /assets/images/blog/250131/post-1.png
author: tjswodud
tags:
    - [DirectX12, Graphics]
---

<h4><a href="https://velog.io/@tjswodud/DirectX12-Initializing-DirectX-12" target="_blank">Read More</a></h4>